package com.jpmorgan.stockmarket.test;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;




import com.jpmorgan.stockmarket.enumeration.StockType;
import com.jpmorgan.stockmarket.gbce.GBCEAllshareIndex;
import com.jpmorgan.stockmarket.impl.Stock;



public class GBCEAllShareIndexTest {

	@Test
	public void testAllShareIndex() {
      HashMap<String,Stock> hmap = new HashMap<String,Stock>();
      hmap.put("TEA", new Stock("TEA", StockType.COMMON, 0.0, 0.0, 100.0));
      hmap.put("POP", new Stock("POP", StockType.COMMON, 8.0, 0.0, 100.0));
      hmap.put("ALE", new Stock("ALE", StockType.COMMON, 23.0, 0.0, 60.0));
      hmap.put("GIN", new Stock("GIN", StockType.PREFERRED, 8.0, 0.2, 100.0));
      hmap.put("JOE", new Stock("JOE", StockType.COMMON, 13.0, 0.0, 250.0));
      for (Stock stock: hmap.values()) {
          // Record some trades
      	for (int i=1; i <= 10; i++) {
      		stock.buy(1, 1.0);
      		stock.sell(1, 1.0);
      	}
      }
      Double GBCEallShareIndex = GBCEAllshareIndex.allShareIndex(hmap);
      assertEquals(1.379729661461215, GBCEallShareIndex, 0.0);
	}

}
