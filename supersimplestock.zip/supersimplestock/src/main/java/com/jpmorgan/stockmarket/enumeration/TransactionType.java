package com.jpmorgan.stockmarket.enumeration;

/**
 * Transaction Types (BUY or SELL)
 *
 */
public enum TransactionType 
{
	BUY, SELL
}
