package com.jpmorgan.stockmarket.enumeration;

/**
 * Stock Types
 *
 */
public enum StockType 
{
	COMMON, PREFERRED
}
