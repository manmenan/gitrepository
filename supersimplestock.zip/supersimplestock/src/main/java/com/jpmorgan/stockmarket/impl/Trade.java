package com.jpmorgan.stockmarket.impl;

import com.jpmorgan.stockmarket.enumeration.TransactionType;



/**
 * Sets Trade information.
 *
 */
public class Trade {
	
	private TransactionType type;
	private Integer quantity;
	private Double price;

	public TransactionType getType() {
		return type;
	}

	public void setType(TransactionType type) {
		this.type = type;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Trade(TransactionType type, Integer quantity, Double price) {
		this.setType(type);
		this.setQuantity(quantity);
		this.setPrice(price);
	}

	@Override
	public String toString() {
		return "Trade [type=" + type + ", quantity=" + quantity + ", price="
				+ price + "]";
	}
}
