package com.jpmorgan.stockmarket;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.jpmorgan.stockmarket.enumeration.StockType;
import com.jpmorgan.stockmarket.gbce.GBCEAllshareIndex;
import com.jpmorgan.stockmarket.impl.Stock;

/**
 * @author pran
 *
 */
@Configuration
@ComponentScan
public class SuperStockApplication {
	private static Log log = LogFactory.getLog(SuperStockApplication.class);

	@Bean
	Map<String, Stock> StockData() {
		HashMap<String, Stock> stockdb = new HashMap<String, Stock>();
		stockdb.put("TEA", new Stock("TEA", StockType.COMMON, 0.0, 0.0, 100.0));
		stockdb.put("POP", new Stock("POP", StockType.COMMON, 8.0, 0.0, 100.0));
		stockdb.put("ALE", new Stock("ALE", StockType.COMMON, 23.0, 0.0, 60.0));
		stockdb.put("GIN", new Stock("GIN", StockType.PREFERRED, 8.0, 0.2,
				100.0));
		stockdb.put("JOE", new Stock("JOE", StockType.COMMON, 13.0, 0.0, 250.0));
		return stockdb;
	}

	public static void main(String[] args) {
		try {
			ApplicationContext stockContext = new AnnotationConfigApplicationContext(
					SuperStockApplication.class);

			// Run dividend and P/E Ratio routines
			@SuppressWarnings("unchecked")
			Map<String, Stock> db = stockContext
					.getBean("StockData", Map.class);
			for (Stock stock : db.values()) {
				log.debug(stock.getstockSymbol() + " dividend: "
						+ stock.dividend(10.5));
				log.debug(stock.getstockSymbol() + " P/E Ratio: "
						+ stock.PERatio(11.8));
				// Record some trades
				for (int i = 1; i <= 15; i++) {
					Random r = new Random();
					Integer rangeMin = 1;
					Integer rangeMax = 15;
					double randomValue = rangeMin + (rangeMax - rangeMin)
							* r.nextDouble();
					stock.buy(i, randomValue);
					log.debug(stock.getstockSymbol() + " bought " + i
							+ " shares at $" + randomValue);
					randomValue = rangeMin + (rangeMax - rangeMin)
							* r.nextDouble();
					stock.sell(i, randomValue);
					log.debug(stock.getstockSymbol() + " sold " + i
							+ " shares at $" + randomValue);
					Thread.sleep(500);
				}
				log.debug(stock.getstockSymbol() + " price: $"
						+ stock.getPrice());
				log.debug(stock.getstockSymbol()
						+ " volumeWeightedStockPrice: $"
						+ stock.calculateVolumeWeightedStockPrice());
			}
			Double GBCEallShareIndex = GBCEAllshareIndex.allShareIndex(db);
			log.debug("GBCE All Share Index: " + GBCEallShareIndex);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
}
